﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            var ttv = new List<ExpandoObject> { AddItems() };

            var param = Expression.Parameter(typeof(ExpandoObject));
            var exp = CreateExpression(ttv, "text");
            var exp1= Expression.Lambda<Func<ExpandoObject, bool>>(exp, param);
            

            ttv.Where(exp1.Compile());


        }

        private static Expression CreateExpression(List<ExpandoObject> itemList, string filter) {



            return null;
        }

        private static ExpandoObject AddItems()
        {
            var item = new ExpandoObject();
            var targetCollection = item as IDictionary<string, object>;
            //foreach (var key in rowItem.Keys)
            //{
            // var value = rowItem[key];
            //    if (value == DBNull.Value)
            //  {
            //   value = null;
            // }
            targetCollection.Add("aitlFindings", "Pnemotherax, Cancer, Unknown");
            //}
            //folderItems.Add(item);
            return item;
        }
    }
}
